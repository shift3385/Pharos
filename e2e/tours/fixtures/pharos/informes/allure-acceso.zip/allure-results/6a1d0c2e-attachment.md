Cuenta: liomar.qa@pharos.test
Resultado: se abre «Inicio» con «Hola, Liomar».
